# Data — External Dataset Acquisition

This directory intentionally does **not** contain the CWRU or NASA IMS datasets.
Both are third-party, publicly available archives with their own hosting and
citation terms, and are not redistributed as part of this reproducibility
package.

The self-contained verification scripts (`verification/verify_simulator.py`,
`verify_commissioning.py`, `verify_pipeline.py`) do **not** require anything in
this directory and can be run without completing any of the steps below.

## How the code finds the data

`code/data_paths.py` resolves each dataset in this order, first hit wins:

1. an environment variable — `CWRU_DATA_ROOT` / `NASA_IMS_DATA_ROOT`
2. the in-package location — `data/CWRU/` / `data/NASA_IMS/`
3. the legacy sibling layout used during the original runs —
   `../CWRU_Bearing_NumPy-main/Data` / `../NASA_Bearing/IMS`

No notebook contains a hard-coded path. Check what is currently resolvable with:

```bash
python code/data_paths.py
```

---

## 1. Case Western Reserve University (CWRU) Bearing Data Center

- **Source:** CWRU Bearing Data Center, Drive-End dataset.
  <https://engineering.case.edu/bearingdatacenter>
- **Conditions used:** 1730, 1750, 1772, 1797 RPM — four operating conditions
  treated as independent deployment environments.
- **Windows used:** healthy 1,414 · ball fault 1,621 · inner-race fault 1,621 ·
  outer-race fault 2,846. Windows are 1,200 samples at 12 kHz (100 ms),
  non-overlapping, matching the shared representation's expected input length.

### Expected format — NumPy, not raw MATLAB

The loaders in `code/cwru_loader.py` read the **NumPy (`.npz`) conversion** of
the Drive-End data, one directory per operating condition, with each archive
exposing the key `"DE"`:

```
<root>/
  1730 RPM/
    1730_Normal.npz          healthy
    1730_B_*_DE12.npz        ball fault
    1730_IR_*_DE12.npz       inner race
    1730_OR*@*_DE12.npz      outer race
  1750 RPM/ ...
  1772 RPM/ ...
  1797 RPM/ ...
```

The CWRU Data Center distributes `.mat` files. Convert them to this layout, or
use an existing NumPy conversion of the Drive-End data, before pointing the
package at the result. The original runs used a local directory named
`CWRU_Bearing_NumPy-main/Data` with exactly this structure.

Then either:

```bash
export CWRU_DATA_ROOT=/path/to/that/directory
```

or place/symlink it at `data/CWRU/`.

- **Citation:** cite the CWRU Bearing Data Center per their stated terms, and
  Smith & Randall, *Mechanical Systems and Signal Processing* 64–65:100–131
  (2015), doi:10.1016/j.ymssp.2015.04.021. This package does not alter or
  redistribute their files.

---

## 2. NASA Intelligent Maintenance Systems (IMS) Bearing Dataset

- **Source:** NASA Prognostics Data Repository, IMS bearing run-to-failure
  dataset, Set No. 2 (referred to as Experiment 2 in the code).
  <https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/>
- **Bearings used:** four independently monitored bearings, each with 984
  chronologically ordered recordings at 10-minute intervals.

### Expected format

The loader reads the extracted experiment directories, with one file per
recording named by timestamp (`YYYY.MM.DD.HH.MM.SS`):

```
<root>/
  2nd_test/
    2004.02.12.10.32.39
    2004.02.12.10.42.39
    ...
```

Only `2nd_test` is enabled in `load_nasa_ims_bearing`; the entries for
experiments 1 and 3 are present but commented out. Experiment 2 has one channel
per bearing, so `sensor_index` must remain 0.

Then either:

```bash
export NASA_IMS_DATA_ROOT=/path/to/that/directory
```

or place/symlink it at `data/NASA_IMS/`.

- **Citation:** Lee, J., Qiu, H., Yu, G., Lin, J., and Rexnord Technical
  Services, *IMS Bearing Data Set*, NASA Ames Prognostics Data Repository (2007).

### Protocol note

Two conventions appear in `bearing_autoencoder_NASA_per_asset.ipynb`. The
reported results use **mean** window aggregation and an **8-of-10** persistence
rule (cells 19, 22, 25). The 95th-percentile aggregation and 3-of-5 persistence
constants in cell 7 belong to a superseded earlier pipeline. See
`REPRODUCIBILITY.md`, Known Limitations item 4, before comparing against
reported numbers.

---

## 3. Synthetic data — no download required

`code/bearing_simulator.py` generates its own nominal and fault-regime signals
at runtime, deterministically given a seeded global NumPy state. Nothing needs
to be placed in this directory to run the simulator, the commissioning
verification, or the end-to-end pipeline verification.

---

## Directory layout once populated

```
data/
  CWRU/
    1730 RPM/  1750 RPM/  1772 RPM/  1797 RPM/     <- .npz per regime
  NASA_IMS/
    2nd_test/                                       <- timestamped recordings
```

## Notes

- Do not commit or redistribute raw dataset files in any derived repository or
  archive; both datasets remain governed by their original providers' terms.
  `.gitignore` excludes `data/CWRU/` and `data/NASA_IMS/` for this reason.
- All calibration and evaluation steps operate on exported one-dimensional
  residual streams once the shared representation has produced them, so raw data
  is needed only once, at the residual-extraction step.
